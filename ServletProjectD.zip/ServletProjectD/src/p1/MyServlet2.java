package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet2
 */
public class MyServlet2 extends HttpServlet {
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<String> jobs = new ArrayList<String>();
		
		
		//getting the attribute from servlet1 like technology and city
		String technology = (String)request.getAttribute("technology");
		String city=(String)request.getAttribute("city");
		
		
		System.out.println(" servlet 2 "+technology+"city "+city);
		out.print("<br/> Technology From Servlet 1 "+technology+" city seletced : "+city);
		
		
		
		
		if(technology.equalsIgnoreCase("java")&&city.contentEquals("New Delhi")) // DB
		{
			jobs.add("Java Developer");
			jobs.add("Full Stack Developer");
			jobs.add("Java Trainer");
			
			
		}else
		if(technology.equalsIgnoreCase("java")&&city.contentEquals("Noida")) //DB
		{
			jobs.add("Java Fresher");
			jobs.add("Java Developer");
			
		}
		else
		if(technology.equalsIgnoreCase("java")&&city.contentEquals("Greater Noida")) //DB
		{
			jobs.add("Java Trainer");
			
			
		}else
		if(technology.equalsIgnoreCase("html")&&city.contentEquals("Greater Noida")) //DB
		{
			jobs.add("Web Developer");
			jobs.add("Web Designer");
			
		}else
		if(technology.equalsIgnoreCase("html")&&city.contentEquals("Noida")) //DB
		{
			jobs.add("Web Developer");
			
			
		}else
		if(technology.equalsIgnoreCase("html")&&city.contentEquals("New Delhi")) //DB
		{
			jobs.add("Web Developer");
			jobs.add("Web Designer");
			
		}else
		if(technology.equalsIgnoreCase("javascript")&&city.contentEquals("New Delhi")) //DB
		{
			jobs.add("Javascript Trainer");
			jobs.add("Web Developer");
			
		}else
		if(technology.equalsIgnoreCase("javascript")&&city.contentEquals("Greater Noida")) //DB
		{
			jobs.add("Web Developer");
		
			
		}else
		//DB
		{if(technology.equalsIgnoreCase("javascript")&&city.contentEquals("Noida")) 
			jobs.add("Javascript Trainer");
			
			
		}
		request.setAttribute("jobs", jobs);
		
		request.getRequestDispatcher("MyServlet3").forward(request, response);
		
		
		
	
	}

}


